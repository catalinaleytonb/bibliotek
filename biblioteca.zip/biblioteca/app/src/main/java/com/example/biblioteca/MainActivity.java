package com.example.biblioteca;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

//librerias sql
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;


//librerias que utilizaremos
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    //declaramos las variables para enlazar los ID
    private TextView textView;
    private ImageView imageView;
    private ProgressBar progressBar;
    private Button btnWeb, btnAgregar, btnConsultar, btnModificar;
    private SQLiteDatabase sqLiteDatabase;
    private EditText editText;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //se enlazan id
        textView = findViewById(R.id.text1);
        imageView = findViewById(R.id.imagenPrueba);
        progressBar = findViewById(R.id.barraProgreso);
        btnWeb = findViewById(R.id.btnWeb);
        btnAgregar = findViewById(R.id.btnAgregar);
        btnModificar = findViewById(R.id.btnModificar);
        spinner = findViewById(R.id.spSpinner);


        //se crea el thead para simular la imagen y texto
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {

                //tiempo de pausa
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //actualizamos la interfaz del usuario desde el hilo principal
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //ocultar barra del progrso
                        progressBar.setVisibility(View.GONE);

                        //mostrar texto actualizado
                        textView.setText("Bienvendos a Bibliotek");

                        //que sea visible el ImageView
                        imageView.setVisibility(View.VISIBLE);

                        //cambiar la imagen si es necesario
                        imageView.setImageResource(R.drawable.b);

                        // Abrir un enlace web
                        btnWeb.setOnClickListener(v -> {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.authorama.com"));
                            startActivity(intent);
                        });
                    }

                });
            }

        });
        //se da de inicio el thread
        thread.start();


    }
}